import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../data/books.dart';
import 'card/bookcard.dart';

class Home extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return HomeState();
  }
}

class HomeState extends State<Home>{
  final List<bool> _selectedBookTypes = <bool>[false, false, false, true];
  final List<Widget> bookTypes = <Widget>[ 
    Text('Buku', style: GoogleFonts.montserrat( fontWeight: FontWeight.w700)), 
    Text('Majalah',style: GoogleFonts.montserrat( fontWeight: FontWeight.w700)), 
    Text('Jurnal', style: GoogleFonts.montserrat( fontWeight: FontWeight.w700)),
    Text('All', style: GoogleFonts.montserrat( fontWeight: FontWeight.w700))];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 20.0, right: 10.0, left: 10.0),
      child: SingleChildScrollView(
        child: Column (
          mainAxisAlignment: MainAxisAlignment.start,
          children: [ 
            Text('Koleksi Buku', textAlign: TextAlign.center, style: GoogleFonts.montserrat(fontWeight: FontWeight.w700, fontSize: 30.0)),
            ToggleButtons(
                direction: Axis.horizontal,
                constraints: const BoxConstraints(
                  minHeight: 40.0,
                  minWidth: 80.0,
                ),
                onPressed: (int index) {
                  setState(() {
                    for (int i = 0; i < _selectedBookTypes.length; i++) {
                      _selectedBookTypes[i] = i == index;
                    }
                  });
                },
                isSelected: _selectedBookTypes,
                children: bookTypes,
            ),
            Column(children: makeBookCategory()) 
          ]
        )
      )
    );
  }

  List<Widget> makeBookCategory() {
    List<Widget> bookCards = [];
    if(_selectedBookTypes[3]) {
      for(int i = 0; i < 12; i++) {
        bookCards.add(BookCard(book: books[i], isHomePage: true));
      }
    } else {
      for(int i = 0; i < 3; i++) {
        if(_selectedBookTypes[i]) {
            for (var j = 0; j < 4; j++) {
              bookCards.add(BookCard(book: books[j + (i * 4)], isHomePage: true));
          }
        }
      }
    }
    return bookCards;
  }
}