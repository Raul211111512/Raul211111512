import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../data/books.dart';
import 'card/bookcard.dart';

class Account extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return AccountState();
  }
}

class AccountState extends State<Account>{
    final List<bool> _selectedAccountTypes = <bool>[true, false];
    final List<Widget> accountTypes = <Widget>[ 
      Text('Dipinjamin', style: GoogleFonts.montserrat( fontWeight: FontWeight.w700)), 
      Text('Dikembalikan',style: GoogleFonts.montserrat( fontWeight: FontWeight.w700))
    ];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 20.0, right: 10.0, left: 10.0),
      child : Column (
          mainAxisAlignment: MainAxisAlignment.start,
          children: [ 
            Text('Riwayat Penminjaman Buku', textAlign: TextAlign.center, style: GoogleFonts.montserrat(fontWeight: FontWeight.w700, fontSize: 30.0)),
            ToggleButtons(
                direction: Axis.horizontal,
                constraints: const BoxConstraints(
                  minHeight: 40.0,
                  minWidth: 120.0,
                ),
                onPressed: (int index) {
                  setState(() {
                    for (int i = 0; i < _selectedAccountTypes.length; i++) {
                      _selectedAccountTypes[i] = i == index;
                    }
                  });
                },
                isSelected: _selectedAccountTypes,
                children: accountTypes,
            ),
            Flexible(
              child: chooseAccountType()
            ),
          ]
        ),
    );
  }

  Widget chooseAccountType() {
    if(_selectedAccountTypes[0]) {
      return createCheckedOutBookCards();
    } else {
      return createReturnedBookCards();
    }
  }

  Widget createCheckedOutBookCards() {
    if(checked_out.isEmpty) {
      return Text('No checked out books', style:GoogleFonts.montserrat());
    } else {
      return 
      ListView.builder(
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        itemCount: checked_out.length,
        itemBuilder: (context, index) => BookCard(book: checked_out[index], isHomePage: false)
      );
    }
  }

  Widget createReturnedBookCards() {
    if(returned.isEmpty) {
      return Text('No returned books', style:GoogleFonts.montserrat());
    } else {
      return 
      ListView.builder(
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        itemCount: returned.length,
        itemBuilder: (context, index) => BookCard(book: returned[index], isHomePage: true)
      );
    }
  }
}