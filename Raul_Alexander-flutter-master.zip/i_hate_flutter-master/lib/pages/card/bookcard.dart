import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../data/books.dart';


class BookCard extends StatefulWidget {
  late Book book; 
  bool isHomePage;

  BookCard ({ Key ? key, required this.book, required this.isHomePage }): super(key: key);

  @override
  BookCardState createState() => BookCardState();
}


class BookCardState extends State<BookCard> {
  bool _isCheckedOut = false; 

  @override
  void initState() {
    super.initState();
    _isCheckedOut = checked_out.contains(widget.book);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: const EdgeInsets.only(top: 5.0, bottom: 5.0),
        child: buildCard(widget.book, widget.isHomePage)
      );
  }

  Card buildCard(Book book, bool isHomePage) {
   return Card(
       semanticContainer: false,
       elevation: 0.0,
       color: Colors.transparent,
       child: isHomePage ? homePageBookCard(book) : accountBookCard(book),
      );
 }

  Widget homePageBookCard(Book book) {
    List<Widget> card = [
      Container(
        height: 121.0,
        width: 100.0,
        padding: EdgeInsets.all(10.0),
        child: Ink.image(
          image: AssetImage(book.image),
          fit: BoxFit.cover,
        ),
      ),
      Padding(
        padding: const EdgeInsets.only(left: 40.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.only(top: 5.0),
              child: Text(
                book.title,
                style: GoogleFonts.montserrat( fontWeight: FontWeight.w700)
              ),
            ),
            Container(
              child: Text(
                book.author,
                style: GoogleFonts.montserrat()
              ),
            ),
            Container(
                padding: EdgeInsets.all(0.0),
                child: ElevatedButton(
                  onPressed: checked_out.contains(book) ? null : () => checkoutBook(book),
                  child: checked_out.contains(book) ? Text('Dipinjamin', style: GoogleFonts.montserrat()) : Text('Pinjam', style: GoogleFonts.montserrat()),
                ),
              )
          ]
        )
      )
    ];

    return Row( 
        mainAxisSize: MainAxisSize.max, children: card);
  }

  Widget accountBookCard(Book book) {
    List<Widget> card = [
      Container(
        height: 121.0,
        width: 100.0,
        padding: EdgeInsets.all(10.0),
        child: Ink.image(
          image: AssetImage(book.image),
          fit: BoxFit.cover,
        ),
      ),
      Padding(
        padding: const EdgeInsets.only(left: 40.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.only(top: 5.0),
              child: Text(
                book.title,
                style: GoogleFonts.montserrat( fontWeight: FontWeight.w700))
            ),
            Container(
              child: Text(
                book.author,
                style: GoogleFonts.montserrat()
              ),
            ),
            Container(
              child: ElevatedButton(
                child: !(checked_out.contains(book)) ? Text('Dikembalikan', style: GoogleFonts.montserrat()) : Text('Kembalikan', style: GoogleFonts.montserrat()),
                onPressed: !(checked_out.contains(book)) ? null : () => returnBook(book)
              )
            )
          ]
        )
      )
    ];

    return Row( 
        mainAxisSize: MainAxisSize.max, children: card);
  }

 void setisCheckedOut(bool isCheckoutOut) {
   setState(() {
      _isCheckedOut = isCheckoutOut;
    });
 }

 void checkoutBook(Book book) async {
    final DateTime? datePicker = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2025),
    );

    if(datePicker != null) {
      checked_out.add(book);

      final snackBar = SnackBar(
        content: Text('${book.title} dipinjam.')
      );

      ScaffoldMessenger.of(context).showSnackBar(snackBar);
      setisCheckedOut(true);
    }
 }

  void returnBook(Book book) {
    checked_out.remove(book);
    if(!returned.contains(book)) { returned.add(book); }

    final snackBar = SnackBar(
      content: Text('${book.title} returned.')
    );

    ScaffoldMessenger.of(context).showSnackBar(snackBar);
    setisCheckedOut(false);
 }
}