class Book {
  final String image, title, author;
  final int id;
  Book({
    this.id = 0,
    this.image = '',
    this.title = '',
    this.author = ''
  });
}

List<Book> books = [
  Book(
    id: 1,
    image: "assets/book1.png",
    title: "Rantau 1 Muara",
    author: "Ahmad Faudi"
  ),
  Book(
    id: 2,
    image: "assets/book2.png",
    title: "Padang Bulan",
    author: "Andrea Hirata"
  ),
  Book(
    id: 3,
    image: "assets/book3.png",
    title: "Bumi",
    author: "Tere Livye",
  ),
  Book(
    id: 4,
    image: "assets/book4.png",
    title: "Child of all Nations",
    author: "Pramoedya Ananta Toer"
  ),
  Book(
    id: 5,
    image: "assets/book5.png",
    title: "Geo Energi",
    author: "PT Multimedia"
  ),
  Book(
    id: 6,
    image: "assets/book6.png",
    title: "F1 Racing",
    author: "PT Tunas BOLA"
  ),
  Book(
    id: 7,
    image: "assets/book7.png",
    title: "Vista TV",
    author: "PT Vista Yama"
  ),
  Book(
    id: 8,
    image: "assets/book8.png",
    title: "Hidup",
    author: "Yayasan Hidup Katolik"
  ),
  Book(
    id: 9,
    image: "assets/book9.png",
    title: "Theories in Programming",
    author: "Jayadev Misra"
  ),
  Book(
    id: 10,
    image: "assets/book10.png",
    title: "Spatial Gems, Volume 1",
    author: "John Krumm, Andreas Züfle"
  ),
  Book(
    id: 11,
    image: "assets/book11.png",
    title: "Jurnal Farmasi Klini",
    author: "Agus"
  ),
  Book(
    id: 12,
    image: "assets/book12.png",
    title: "Jurnal Pengajarkan MIPA",
    author: "JPMIPA"
  ),
];

// Checked out books
List<Book> checked_out = [];
// Returned books
List<Book> returned = [];